#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,sum=0;
printf("SUM OF TWO NUMBERS\n ");
printf("-------------------\n");
printf("Enter the two numbers :");
scanf("%d %d",&a,&b);
sum=a+b;

printf("Sum is %d",sum);
getch();
}
